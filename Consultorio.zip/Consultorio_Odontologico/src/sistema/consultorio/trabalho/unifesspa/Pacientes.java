package sistema.consultorio.trabalho.unifesspa;

import java.sql.Date;
import java.sql.Time;

public class Pacientes extends Consultorio{
	
	private int idade;
	private Date dataDoInicioDoTratamento;
	private String tratamentosFeitos;
	private String tratamentosMarcados;
	private Date dataDosTratamentosMarcados;
	private Time horaDaProximaConsulta;
	
	public Pacientes(String nome, String endereco, String cpf, int idade) {
		super(nome, endereco, cpf);
		this.idade = idade;
	}


	public Date getDataDoInicioDoTratamento() {
		return dataDoInicioDoTratamento;
	}


	public void setDataDoInicioDoTratamento(Date dataDoInicioDoTratamento) {
		dataDoInicioDoTratamento = dataDoInicioDoTratamento;
	}


	public String getTratamentosFeitos() {
		return tratamentosFeitos;
	}


	public void setTratamentosFeitos(String tratamentosFeitos) {
		tratamentosFeitos = tratamentosFeitos;
	}


	public String getTratamentosMarcados() {
		return tratamentosMarcados;
	}


	public void setTratamentosMarcados(String tratamentosMarcados) {
		tratamentosMarcados = tratamentosMarcados;
	}


	public Date getDataDosTratamentosMarcados() {
		return dataDosTratamentosMarcados;
	}


	public void setDataDosTratamentosMarcados(Date dataDosTratamentosMarcados) {
		dataDosTratamentosMarcados = dataDosTratamentosMarcados;
	}


	public Time getHoraDaProximaConsulta() {
		return horaDaProximaConsulta;
	}


	public void setHoraDaProximaConsulta(Time horaDaProximaConsulta) {
		horaDaProximaConsulta = horaDaProximaConsulta;
	}
	
}
