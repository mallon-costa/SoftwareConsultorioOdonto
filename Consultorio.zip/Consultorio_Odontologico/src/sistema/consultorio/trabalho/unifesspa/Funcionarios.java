package sistema.consultorio.trabalho.unifesspa;

public class Funcionarios extends Consultorio{
	
	protected double salario;
	protected String dataIngressao;
	protected double cargaSemanal;
	protected String genero;
	protected int idade;
	protected String formacao;
	
	
	public Funcionarios(String nome, String endereco, String cpf, double salario, String dataIngressao, double cargaSemanal, String genero,int idade, String formacao) {
		super(nome, endereco, cpf);
		this.salario = salario;
		this.dataIngressao = dataIngressao;
		this.cargaSemanal = cargaSemanal;
		this.genero = genero;
		this.idade = idade;
		this.formacao = formacao;
	}


	public double getSalario() {
		return salario;
	}


	public void setSalario(double salario) {
		this.salario = salario;
	}


	public String getDataIngressao() {
		return dataIngressao;
	}


	public void setDataIngressao(String dataIngressao) {
		this.dataIngressao = dataIngressao;
	}


	public double getCargaSemanal() {
		return cargaSemanal;
	}


	public void setCargaSemanal(double cargaSemanal) {
		this.cargaSemanal = cargaSemanal;
	}


	public String getGenero() {
		return genero;
	}


	public void setGenero(String genero) {
		this.genero = genero;
	}


	public int getIdade() {
		return idade;
	}


	public void setIdade(int idade) {
		this.idade = idade;
	}


	public String getFormacao() {
		return formacao;
	}


	public void setFormacao(String formacao) {
		this.formacao = formacao;
	}
	
	
	
}
