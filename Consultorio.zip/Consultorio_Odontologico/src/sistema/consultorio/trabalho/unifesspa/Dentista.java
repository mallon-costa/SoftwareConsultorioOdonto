package sistema.consultorio.trabalho.unifesspa;

public class Dentista extends Funcionarios{
	private String especializacao;

	public Dentista(String nome, String endereco, String cpf, double salario, String dataIngressao, double cargaSemanal,
			String genero, int idade, String formacao) {
		super(nome, endereco, cpf, salario, dataIngressao, cargaSemanal, genero, idade, formacao);
	}

	public String getEspecializacao() {
		return especializacao;
	}

	public void setEspecializacao(String especializacao) {
		this.especializacao = especializacao;
	}
	
}
