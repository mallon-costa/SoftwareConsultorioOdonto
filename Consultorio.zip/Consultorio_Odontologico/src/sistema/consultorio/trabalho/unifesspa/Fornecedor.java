package sistema.consultorio.trabalho.unifesspa;

public class Fornecedor extends Consultorio{
	private String dataEntrega;
	private String produtos;
	
	
	public Fornecedor(String nome, String endereco, String cpf, String produtos, String dataEntregra) {
		super(nome, endereco, cpf);
		this.dataEntrega = dataEntrega;
		this.produtos = produtos;
	}


	public String getDataEntrega() {
		return dataEntrega;
	}


	public void setDataEntrega(String dataEntrega) {
		this.dataEntrega = dataEntrega;
	}


	public String getProdutos() {
		return produtos;
	}


	public void setProdutos(String produtos) {
		this.produtos = produtos;
	}
	
}
